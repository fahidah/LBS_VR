﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public bool isGameActive;

    public InstructorController instructor;

    public GameObject titleScreen, mainScreen, gameOverScreen;

    public TMP_InputField answer;
    public TextMeshProUGUI firstOperandText, secondOperandText, operatorText, gameOverText, scoreText, timeText, remarks; 
    public Button restartButton;

    public int missCounter, hitCounter;
    public int firstOperand, secondOperand;
    private int getOperator;
    private int score;

    public string[] myOperator;

    public float timeLeft;


    // Start Game
    public void startGame()
    {
        isGameActive = true;
        titleScreen.gameObject.SetActive(false);
        mainScreen.gameObject.SetActive(true);
        RandomNumberGenerator();

        StartCoroutine(RepeatRandomNumberGenerator());
    }

    // Generate the Operands and Operators randomly
    void RandomNumberGenerator()
    {
        firstOperand = Random.Range(1, 12);
        firstOperandText.text = "" + firstOperand;

        secondOperand = Random.Range(1, 12);
        secondOperandText.text = "" + secondOperand;

        getOperator = Random.Range(0, myOperator.Length);
        operatorText.text = "" + myOperator[getOperator];
    }


    //Check if the inputted answer is correct
    public void checkAnswer()
    {
        int expectedResult;

        //perform calculation

        if (operatorText.text == "+")
        {
            expectedResult = int.Parse(firstOperandText.text) + int.Parse(secondOperandText.text);
            if (expectedResult.ToString() == answer.text)
            {
                remarks.text = "You're correct! well done";
                instructor.Bow();
                UpdateScore(5);

                hitCounter++;
            }
            else
            {
                remarks.text = "Wrong! The answer is " + expectedResult;
                missCounter++;
            }
        }

        else if (operatorText.text == "*")
        {
            expectedResult = int.Parse(firstOperandText.text) * int.Parse(secondOperandText.text);
            if (expectedResult.ToString() == answer.text)
            {
                remarks.text = "You're correct! well done";
                instructor.Bow();
                UpdateScore(5);

                hitCounter++;
            }
            else
            {
                remarks.text = "Wrong! The answer is " + expectedResult;
                missCounter++;
            }

        }

        else if (operatorText.text == "-")
        {
            expectedResult = int.Parse(firstOperandText.text) - int.Parse(secondOperandText.text);
            if (expectedResult.ToString() == answer.text)
            {
                remarks.text = "You're correct! well done";
                instructor.Bow();
                UpdateScore(5);
                
                hitCounter++;

            }
            else
            {
                remarks.text = "Wrong! The answer is " + expectedResult;
                missCounter++;
            }
        }

        else if (operatorText.text == "/")
        {
            float expectedResultForDivision = float.Parse(firstOperandText.text) / float.Parse(secondOperandText.text);
            if (expectedResultForDivision.ToString() == answer.text)
            {
                remarks.text = "You're correct! well done";
                instructor.Bow();
                UpdateScore(5);
                
                hitCounter++;
            }
            else
            {
                remarks.text = "Wrong! The answer is " + expectedResultForDivision;
                missCounter++;
            }
        }

        else Debug.Log("How??????!!!");

        OnMouseEnter();

        GameOver(missCounter);
    }


    // Coroutine
    IEnumerator RepeatRandomNumberGenerator(float countDown = 10)
    {
        while ( isGameActive )
        {
            timeLeft = countDown;

            while (timeLeft >= 0)
            {

                timeText.text = "Time Left: " + timeLeft;
                yield return new WaitForSeconds(1);
                timeLeft--;

                if(timeLeft == 0)
                {
                    RandomNumberGenerator();
                }
            } 
        }

    }


    // Do this when the game is over
    public void GameOver(int missCount)
    {
        if (missCount == 3)
        {
            gameOverScreen.gameObject.SetActive(true);
            isGameActive = false;
        }
    }



    // Load the scene again to restart
    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }



    // This keeps track of scores
    private void UpdateScore(int scoreToAdd)
    {
        score += scoreToAdd;
        scoreText.text = "Score: " + score;
    }



    private void OnMouseEnter()
    {
        RandomNumberGenerator();
        answer.text = "";
        timeLeft = 11;
    }
}
    
